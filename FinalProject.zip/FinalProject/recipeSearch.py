import tkinter as tk
from tkinter import Listbox, Scrollbar, messagebox

# Class to reserch a recipe
class RecipeSearch:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("RecipeSearch")
        self.root.geometry("400x300")
        self.root.configure(bg="pink")

        # Search Entry and Button
        self.searchLabel = tk.Label(self.root, text="Search:", font=("Helvetica", 12), bg="pink")
        self.searchLabel.pack(pady=10)
        self.searchEntry = tk.Entry(self.root)
        self.searchEntry.pack(pady=5)
        self.searchButton = tk.Button(self.root, text="Search", command=self.searchRecipes)
        self.searchButton.pack(pady=5)

        # Recipe Listbox and Scrollbar
        self.recipeListbox = Listbox(self.root, width=50)
        self.recipeListbox.pack(pady=10, fill=tk.BOTH, expand=True)

        self.scrollbar = Scrollbar(self.root, orient=tk.VERTICAL)
        self.scrollbar.config(command=self.recipeListbox.yview)
        self.scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.recipeListbox.config(yscrollcommand=self.scrollbar.set)

        # To populate recipe listbox placeholder
        self.populateRecipeListbox()

    # Placeholder to populate recipe listbox
    def populateRecipeListbox(self):
       
        recipes = [
            "Apple Pie",
            "Tomato Soup",
            "Grilled Cheese",
            "Beef Stew",
            "Vegetable Stir-Fry"
        ]
        for recipe in recipes:
            self.recipeListbox.insert(tk.END, recipe)

    # Placeholder to search for recipes
    def searchRecipes(self):
        searchTerm = self.searchEntry.get()
        if searchTerm:
            
            messagebox.showinfo("Search", f"Searching for '{searchTerm}'...")
        else:
            messagebox.showwarning("Search", "Please enter a search term.")

# Start the event loop to keep the program running
if __name__ == "__main__":
    app = RecipeSearch()
    app.root.mainloop()
