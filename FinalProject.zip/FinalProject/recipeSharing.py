import tkinter as tk
from tkinter import messagebox, Button

# Defines the recipes sharing class
class RecipeSharing:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("RecipeSharing")
        self.root.geometry("400x300")
        self.root.configure(bg="pink")

        # Email Button
        self.emailButton = Button(self.root, text="Share via Email", command=self.shareEmail)
        self.emailButton.pack(pady=30)

        # Social Media Button
        self.socialMediaButton = Button(self.root, text="Share on Social Media", command=self.shareSocialMedia)
        self.socialMediaButton.pack(pady=20)

    def shareEmail(self):
        # Placeholder for sharing via email
        messagebox.showinfo("Share via Email", "Sharing recipe via email...")

    def shareSocialMedia(self):
        # Placeholder for sharing on social media
        messagebox.showinfo("Share on Social Media", "Sharing recipe on social media...")

# Start the event loop to keep the program running
if __name__ == "__main__":
    app = RecipeSharing()
    app.root.mainloop()
