class RecipeManager:
    def __init__(self):
        self.recipes = ["Apple Pie", "Tomato Soup", "Grilled Cheese"]

    def addRecipe(self, recipeName):
        # Placeholder to add a recipe
        self.recipes.append(recipeName)

    def deleteRecipe(self, index):
        # Placeholder to delete a recipe
        del self.recipes[index]

    def editRecipe(self, index, newName):
        # Placeholder to edit a recipe
        self.recipes[index] = newName

# Optional: Recipe class
class Recipe:
    def __init__(self, name, ingredients, instructions):
        self.name = name
        self.ingredients = ingredients
        self.instructions = instructions
