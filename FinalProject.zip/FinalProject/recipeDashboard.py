import tkinter as tk
from tkinter import messagebox, Listbox, END, Toplevel, Label, Button, Entry
from RecipeLogic import RecipeManager

# The login function to check credentials and opens the dashboard
def login(username, password):
    if username == "test" and password == "test":
        messagebox.showinfo("Login Success", "Successfully logged in!")
        openDashboard()
    else:
        messagebox.showerror("Login Failed", "Incorrect username or password")

# Opens the recipe dashboard window after login
def openDashboard():
    dashboardWindow = Toplevel()
    dashboardWindow.title("Recipe Dashboard")
    dashboardWindow.geometry("400x300")
    dashboardWindow.configure(bg="pink")  # Set background color to pink
     
    #This displays a label in the dashboard
    Label(dashboardWindow, text="Your Recipes", font=('Helvetica', 16)).pack(pady=10)

    # Displays the list of recipes
    recipeListbox = Listbox(dashboardWindow)
    recipeListbox.pack(pady=10, padx=10, fill=tk.BOTH, expand=True)

    for recipe in recipeManager.recipes:
        recipeListbox.insert(END, recipe)

    # Buttons to add, edit and delete recipes
    Button(dashboardWindow, text="Add New", command=lambda: addRecipe(recipeListbox)).pack(side=tk.LEFT, padx=10)
    Button(dashboardWindow, text="Edit", command=lambda: editRecipe(recipeListbox)).pack(side=tk.LEFT, padx=10)
    Button(dashboardWindow, text="Delete", command=lambda: deleteRecipe(recipeListbox)).pack(side=tk.LEFT, padx=10)

# Add a new recipe to the recipe box
def addRecipe(listbox):
    newRecipeName = "New Recipe"  # Placeholder for user input
    listbox.insert(END, newRecipeName)
    recipeManager.addRecipe(newRecipeName)

# Edit an existing recipe
def editRecipe(listbox):
    selectedIndex = listbox.curselection()
    if selectedIndex:
        selectedRecipe = listbox.get(selectedIndex)
        newName = messagebox.askstring("Edit Recipe", f"Enter new name for '{selectedRecipe}':")
        if newName:
            listbox.delete(selectedIndex)
            listbox.insert(selectedIndex, newName)
            recipeManager.editRecipe(selectedIndex[0], newName)

# delete a selected recipe
def deleteRecipe(listbox):
    selectedIndex = listbox.curselection()
    if selectedIndex:
        selectedRecipe = listbox.get(selectedIndex)
        response = messagebox.askyesno("Delete Recipe", f"Are you sure you want to delete '{selectedRecipe}'?")
        if response:
            listbox.delete(selectedIndex)
            recipeManager.deleteRecipe(selectedIndex[0])

# Main application to the main window
if __name__ == "__main__":
    recipeManager = RecipeManager()
    root = tk.Tk()
    root.title("Recipe App")
    root.geometry("300x200")
    root.configure(bg="pink")  # Set background color to pink

    # login with username and password
    Label(root, text="Username:", bg="pink").pack()  # Set background color to pink
    usernameEntry = Entry(root, bg="pink", fg="white")  # Set background color to pink and text color to white
    usernameEntry.insert(END, "test")  # Set  value to "test"
    usernameEntry.pack()

    Label(root, text="Password:", bg="pink").pack()  # Set background color to pink
    passwordEntry = Entry(root, show="*", bg="pink", fg="white")  # Set background color to pink, the text color to white, and show * for password
    passwordEntry.insert(END, "test")  # Set value to "test"
    passwordEntry.pack()

    # Button to trigger the login process
    loginButton = Button(root, text="Login", command=lambda: login(usernameEntry.get(), passwordEntry.get()))
    loginButton.pack()

    # Start the loop to keep running
    root.mainloop()







