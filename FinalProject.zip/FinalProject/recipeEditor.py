import tkinter as tk
from tkinter import Label, messagebox, Entry, Text, Button, Toplevel

# Defines the recipe editor class
class RecipeEditor:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("RecipeEditor")
        self.root.geometry("400x500")
        self.root.configure(bg="pink")

        # Labels and Entry Fields for recipe
        self.nameLabel = Label(self.root, text="Recipe Name:", bg="pink")
        self.nameLabel.pack(pady=(20, 5))
        self.nameEntry = Entry(self.root)
        self.nameEntry.pack(pady=5)

        # Text fields for ingredients input
        self.ingredientsLabel = Label(self.root, text="Ingredients:", bg="pink")
        self.ingredientsLabel.pack(pady=5)
        self.ingredientsEntry = Text(self.root, height=5)
        self.ingredientsEntry.pack()

        # Text fields for instructions input
        self.instructionsLabel = Label(self.root, text="Instructions:", bg="pink")
        self.instructionsLabel.pack(pady=5)
        self.instructionsEntry = Text(self.root, height=10)
        self.instructionsEntry.pack()

        # Text fields for coking time input
        self.cookingTimeLabel = Label(self.root, text="Cooking Time:", bg="pink")
        self.cookingTimeLabel.pack(pady=5)
        self.cookingTimeEntry = Entry(self.root)
        self.cookingTimeEntry.pack()

        # Save and Return Buttons
        self.saveButton = Button(self.root, text="Save", command=self.saveRecipe)
        self.saveButton.pack(pady=20)
        self.returnButton = Button(self.root, text="Return to Dashboard", command=self.returnToDashboard)
        self.returnButton.pack()

    # Saving handle for the recipe
    def saveRecipe(self):
        name = self.nameEntry.get()
        ingredients = self.ingredientsEntry.get("1.0", tk.END)
        instructions = self.instructionsEntry.get("1.0", tk.END)
        cookingTime = self.cookingTimeEntry.get()

        # Placeholder to save recipe
        messagebox.showinfo("Recipe Saved", "Recipe saved successfully!")

     # Go back to dashboard
    def returnToDashboard(self):
        self.root.destroy()
       
# Event loop to keep the program running
if __name__ == "__main__":
    editor = RecipeEditor()
    editor.root.mainloop()


