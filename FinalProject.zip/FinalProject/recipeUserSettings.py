import tkinter as tk
from tkinter import messagebox, Label, Checkbutton, Button

# Defines the user settings 
class UserSettings:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("UserSettings")
        self.root.geometry("400x300")
        self.root.configure(bg="pink")

        # Display Theme Section
        self.displayThemeLabel = Label(self.root, text="Display Theme", bg="pink", font=("Helvetica", 12))
        self.displayThemeLabel.pack(pady=(20, 5))
        self.darkModeVar = tk.BooleanVar()
        self.darkModeCheckbox = Checkbutton(self.root, text="Dark Mode", variable=self.darkModeVar, bg="pink")
        self.darkModeCheckbox.pack()

        # Notification Settings Section
        self.notificationLabel = Label(self.root, text="Notification Settings", bg="pink", font=("Helvetica", 12))
        self.notificationLabel.pack(pady=(10, 5))
        self.notificationVar = tk.BooleanVar()
        self.notificationCheckbox = Checkbutton(self.root, text="Enable Notifications", variable=self.notificationVar, bg="pink")
        self.notificationCheckbox.pack()

        # Account Management Section
        self.accountButton = Button(self.root, text="Account Management", command=self.accountManagement, bg="white")
        self.accountButton.pack(pady=10)

    def accountManagement(self):
        # Placeholder for account management
        messagebox.showinfo("Account Management", "Redirecting to account management page...")

# start the event loop to keep the program running
if __name__ == "__main__":
    app = UserSettings()
    app.root.mainloop()


