import tkinter as tk
from tkinter import Label, Button, Entry, PhotoImage, Toplevel, messagebox
from PIL import Image, ImageTk

# To open the login window
def openLogin():
    loginWindow = tk.Toplevel()
    loginWindow.title("Login")
    loginWindow.geometry("300x200")
    loginWindow.configure(bg='pink')  # Set the window's background color to pink
    Label(loginWindow, text="Username:").pack(pady=(10, 0))
    usernameEntry = Entry(loginWindow, width=25)
    usernameEntry.pack()
    Label(loginWindow, text="Password:").pack(pady=(10, 0))
    passwordEntry = Entry(loginWindow, width=25, show="*")
    passwordEntry.pack()
    Button(loginWindow, text="Login", command=lambda: login(usernameEntry.get(), passwordEntry.get())).pack(pady=20)

# To handle login information
def login(username, password):
    if username == "admin" and password == "admin":
        messagebox.showinfo("Login Success", "Successfully logged in!")
    else:
        messagebox.showerror("Login Failed", "Incorrect username or password")

# To open the registration window
def openRegister():
    registerWindow = tk.Toplevel()
    registerWindow.title("Register")
    registerWindow.geometry("300x200")
    registerWindow.configure(bg='pink')  # Set the window's background color to pink

    # Username Entry
    Label(registerWindow, text="Username:").pack(pady=(5, 0))
    usernameEntry = Entry(registerWindow, width=25)
    usernameEntry.pack()

    # Email Entry (Optional)
    Label(registerWindow, text="Email (optional):").pack(pady=(5, 0))
    emailEntry = Entry(registerWindow, width=25)
    emailEntry.pack()

    # Password Entry
    Label(registerWindow, text="Password:").pack(pady=(5, 0))
    passwordEntry = Entry(registerWindow, width=25, show="*")
    passwordEntry.pack()

    # Submit Button
    Button(registerWindow, text="Submit", command=lambda: submitRegistration(
        usernameEntry.get(), emailEntry.get(), passwordEntry.get()
    )).pack(pady=20)

# This function for registration submission
def submitRegistration(username, email, password):
    print(f"Username: {username}, Email: {email}, Password: {password}")
    messagebox.showinfo("Registration Successful", "You have been registered successfully!")

# create the main Tkinter window
root = tk.Tk()
root.title("Recipe Organizer Pro")
root.geometry("600x500")
root.configure(bg='pink')  # Set the background color of the main window to pink

# Display the image
imagePath = r"FinalProject\digitalRecipe.jpeg"
img = Image.open(imagePath)
img = img.resize((400, 200), Image.BILINEAR)
img = ImageTk.PhotoImage(img)
imageLabel = Label(root, image=img)
imageLabel.pack()

# This label to welcome users
welcomeLabel = Label(root, text="Welcome to Recipe Organizer Pro")
welcomeLabel.pack(pady=20)

# To open the login window
loginButton = Button(root, text="Login", command=openLogin)
loginButton.pack(pady=10)

# Button to open the registration window
registerButton = Button(root, text="Register", command=openRegister)
registerButton.pack(pady=10)

# Start the event loop to keep the program running
root.mainloop()








